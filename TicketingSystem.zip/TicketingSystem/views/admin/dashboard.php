<?php
require_once "../../backend/includes/auth_shield.php";
enforceAccessShield('admin');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <style>
        body { font-family: 'Segoe UI', sans-serif; padding: 40px; background: #fff5f5; }
        .card { background: white; padding: 30px; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); border-top: 5px solid #dc3545;}
        .btn { display: inline-block; padding: 10px 20px; background: #dc3545; color: white; text-decoration: none; border-radius: 4px; margin-top: 20px;}
    </style>
</head>
<body>
    <div class="card">
        <h1>Admin Control Room</h1>
        <p>Welcome back, <strong><?php echo htmlspecialchars($_SESSION['username']); ?></strong>.</p>
        <p>You have full system access to all support tickets.</p>
        <a href="../../logout.php" class="btn">Disconnect System</a>
    </div>
</body>
</html>