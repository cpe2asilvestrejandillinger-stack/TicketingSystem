<?php
require_once "../../backend/includes/auth_shield.php";
enforceAccessShield('user');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <style>
        body { font-family: 'Segoe UI', sans-serif; padding: 40px; background: #f0f7ff; }
        .card { background: white; padding: 30px; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); border-top: 5px solid #007bff;}
        .btn { display: inline-block; padding: 10px 20px; background: #6c757d; color: white; text-decoration: none; border-radius: 4px; margin-top: 20px;}
    </style>
</head>
<body>
    <div class="card">
        <h1>Support Portal</h1>
        <p>Welcome, <strong><?php echo htmlspecialchars($_SESSION['username']); ?></strong>.</p>
        <p>You can create and track your support tickets here.</p>
        <a href="../../logout.php" class="btn">Logout</a>
    </div>
</body>
</html>