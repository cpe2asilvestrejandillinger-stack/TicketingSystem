<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function enforceAccessShield($requiredRole) {
    if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== $requiredRole) {
        session_unset();
        session_destroy();
        
        // Dynamic directory resolver to pop out to the system root safely
        $rootPath = "http://" . $_SERVER['HTTP_HOST'] . "/ticketing_system/index.html";
        header("Location: " . $rootPath);
        exit;
    }
}
?>