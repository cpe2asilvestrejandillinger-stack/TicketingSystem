<?php
class Database {
    private $host = "localhost";
    private $db_name = "ticketing_system";
    private $username = "root";
    private $password = "";
    public $conn;

    public function getConnection() {
        $this->conn = null;
        try {
            $dsn = "mysql:host=" . $this->host . ";dbname=" . $this->db_name . ";charset=utf8mb4";
            $this->conn = new PDO($dsn, $this->username, $this->password);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        } catch(PDOException $exception) {
            error_log("Database System Error: " . $exception->getMessage());
            header('Content-Type: application/json');
            echo json_encode(["status" => "error", "message" => "Database link failure across network operations."]);
            exit;
        }
        return $this->conn;
    }
}
?>