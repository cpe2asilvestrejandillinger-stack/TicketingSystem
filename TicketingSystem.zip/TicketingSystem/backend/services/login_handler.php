<?php
header("Content-Type: application/json");
require_once "../config/database.php";

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if (empty($username) || empty($password)) {
        echo json_encode(["status" => "error", "message" => "Null values rejected. Input required data."]);
        exit;
    }

    $database = new Database();
    $db = $database->getConnection();

    try {
        $query = "SELECT id, username, password, role FROM users WHERE username = :username LIMIT 1";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':username', $username);
        $stmt->execute();

        if ($stmt->rowCount() === 1) {
            $user = $stmt->fetch();

            if (password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['role'] = $user['role'];

                echo json_encode([
                    "status" => "success",
                    "role" => $user['role'],
                    "message" => "Identity verified. Relocating..."
                ]);
            } else {
                echo json_encode(["status" => "error", "message" => "Credential pairing rejection: Bad password."]);
            }
        } else {
            echo json_encode(["status" => "error", "message" => "Identity mismatch: Username not verified."]);
        }
    } catch (PDOException $e) {
        error_log("Login Interface Exception: " . $e->getMessage());
        echo json_encode(["status" => "error", "message" => "Critical authentication system exception."]);
    }
}
?>