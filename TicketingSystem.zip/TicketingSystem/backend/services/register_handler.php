<?php
header("Content-Type: application/json");
require_once "../config/database.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if (empty($username) || empty($email) || empty($password)) {
        echo json_encode(["status" => "error", "message" => "All registration parameters are required."]);
        exit;
    }

    $database = new Database();
    $db = $database->getConnection();

    try {
        // Look up identity overlaps
        $query = "SELECT id FROM users WHERE username = :username OR email = :email LIMIT 1";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':username', $username);
        $stmt->bindParam(':email', $email);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            echo json_encode(["status" => "error", "message" => "Username identity or email resource matches system registers."]);
            exit;
        }

        // Add user profile
        $hashed_password = password_hash($password, PASSWORD_BCRYPT);
        $insertQuery = "INSERT INTO users (username, email, password, role) VALUES (:username, :email, :password, 'user')";
        $insertStmt = $db->prepare($insertQuery);
        $insertStmt->bindParam(':username', $username);
        $insertStmt->bindParam(':email', $email);
        $insertStmt->bindParam(':password', $hashed_password);

        if ($insertStmt->execute()) {
            echo json_encode(["status" => "success", "message" => "Account successfully configured. Transitioning..."]);
        } else {
            echo json_encode(["status" => "error", "message" => "Internal save faults encountered."]);
        }
    } catch (PDOException $e) {
        error_log("Worker Registry Crash: " . $e->getMessage());
        echo json_encode(["status" => "error", "message" => "Transaction crash processing database data."]);
    }
}
?>