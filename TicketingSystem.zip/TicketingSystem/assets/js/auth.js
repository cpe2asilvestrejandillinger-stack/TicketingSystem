// Toggle Screen views
document.getElementById('toRegister').addEventListener('click', (e) => {
    e.preventDefault();
    document.getElementById('loginBox').classList.add('hidden');
    document.getElementById('registerBox').classList.remove('hidden');
});

document.getElementById('toLogin').addEventListener('click', (e) => {
    e.preventDefault();
    document.getElementById('registerBox').classList.add('hidden');
    document.getElementById('loginBox').classList.remove('hidden');
});

// Centralized Asynchronous Request Processing Engine
async function makeAuthRequest(targetUrl, formElement, feedbackElement) {
    feedbackElement.style.display = "none";
    const formData = new FormData(formElement);

    try {
        const response = await fetch(targetUrl, {
            method: 'POST',
            body: formData
        });

        if (!response.ok) {
            throw new Error(`HTTP network error status: ${response.status}`);
        }

        const data = await response.json();
        feedbackElement.className = `message ${data.status}`;
        feedbackElement.innerText = data.message;

        return data;
    } catch (err) {
        console.error("%c[System Core Error]", "color: red; font-weight: bold;", err);
        feedbackElement.className = "message error";
        feedbackElement.innerText = "Internal error connecting to core authentication APIs.";
        return null;
    }
}

// Bind registration submission
document.getElementById('registerForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const feedback = document.getElementById('registerMessage');
    const result = await makeAuthRequest('backend/services/register_handler.php', e.target, feedback);

    if (result && result.status === 'success') {
        e.target.reset();
        setTimeout(() => document.getElementById('toLogin').click(), 2000);
    }
});

// Bind login submission
document.getElementById('loginForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const feedback = document.getElementById('loginMessage');
    const result = await makeAuthRequest('backend/services/login_handler.php', e.target, feedback);

    if (result && result.status === 'success') {
        setTimeout(() => {
            if (result.role === 'admin') {
                window.location.href = 'views/admin/dashboard.php';
            } else {
                window.location.href = 'views/user/dashboard.php';
            }
        }, 1000);
    }
});