CREATE TABLE IF NOT EXISTS `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(50) NOT NULL UNIQUE,
  `email` VARCHAR(100) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `role` ENUM('user', 'admin') DEFAULT 'user',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Default Admin Account (Username: admin | Password: admin123)
INSERT INTO `users` (`username`, `email`, `password`, `role`) 
VALUES ('admin', 'admin@ticket.com', '$2y$10$wK7.0zRjA2zW8Z8n5O7bUuY1G3Z.b2E3mK6ZgqB8F8d5K2S6S6S6.', 'admin');